﻿using System;

namespace ReaderComponentServiceConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Read();
        }
    }
}
